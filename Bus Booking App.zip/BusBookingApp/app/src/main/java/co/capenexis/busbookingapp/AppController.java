package co.capenexis.busbookingapp;

public class AppController {
    public static Object baseURL;
    public static Object getBusDeatils;
    public static Object singupUserURL;
    public static Object loginUserURL;

    public void setLoginSessionFlg(boolean b) {
    }

    public void setUID(String userID) {
    }
}
